FreeMaker样例：http://localhost:8080/freemarker

Json样例：http://localhost:8080/jsonRequest.html