package com.kwk.dao;

public interface StudentMapper {
    public StudentEntity getStudent(int studentID);
}
