package com.kwk.bbs.member;

public class MemberServiceTest {
}
