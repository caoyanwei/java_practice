package com.kwk.bbs.member.api;


public interface MemberService {
}
