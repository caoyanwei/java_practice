package com.kwk.bbs.member.biz;

import com.kwk.bbs.member.api.MemberService;


public class MemberServiceImpl implements MemberService {
}
