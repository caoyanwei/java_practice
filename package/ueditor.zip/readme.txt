windows下有问题：
FileManager
	private String getPath ( File file ) {

		String path = file.getAbsolutePath();

		return path.replace( this.rootPath, "/" );

	}